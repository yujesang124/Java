

		// 1. 한줄 처리
		// 한줄 주석처리 
		// 2. 범위 주석처리
		/*
			Date : 2020.05.08
			Author : JaesangYu
			Description : Java BasicSetting
			Version : 1.0
		 
		 */


package Java0508;

public class ex01_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// l => 문장의 마침표 역할 
		System.out.println("Hello Jason World");
		System.out.println("Hello guys!!");
		
		// sysout 입력 후 [ctrl] + [space key] 하면 자동완성기능
		System.out.println();
		System.out.println("guys, How are You?");
		System.out.println("[ctrl] + [space key] 를 동시타격하면 자동완성입력가능");
		
		//실행(Run) => [ctrl] + [F11]
		
		//저장(Save) => [ctrl] + [s]
		
		//모두저장(Save all) => [ctrl] + [shift] + [s]
		
		//글자 크게 : [ctrl] + [+]
		//글자 작게 : [ctrl] + [-]
		
		
		/*
		클래스 이름바꾸기
		클래스명' 오른쪽 마우스 클릭 → Refactor → Rename
		※ 프로젝트, 패키지 동
		 */
		
	}

}
