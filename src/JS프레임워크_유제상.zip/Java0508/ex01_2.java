/*
 Date : 
 Author : 
 Description : 
 version : 
 */

package Java0508;

public class ex01_2 {

	public static void main(String[] args) {
// TODO Auto-generated method stub
		System.out.println("들여쓰기 연습");
		System.out.println("[Ctrl] + [Shift] + [F key]를 누르면 자동 들여쓰기 설정");
		
	}

}
