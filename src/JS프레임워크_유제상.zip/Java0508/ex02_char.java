/*
 	Date : 20.05.08
 	Author : JasonYu
 	Description : var char
 	Version : 1.0
 */
package Java0508;


public class ex02_char {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 문자형 변수타입 char(2byte)
		char ch1;
		ch1 = 'A';
		System.out.println("A");
		System.out.println(ch1);
		
		System.out.println((int)ch1);
				
		char ch2 = 'B';
		System.out.println((int) ch2);
		
		char ch3 = 'a';
		char ch4 = 'b';
		System.out.println((int) ch3);
		System.out.println((int) ch4);
		
		int num1 = 65;
		System.out.println((char)num1);
		// 숫자를 문자형으로 바꿀때 변수명 앞에 (char)
		
		char ch5 = 'y';
		System.out.println((int) ch5); //121
		char ch6 = 'u';
		System.out.println((int) ch6); //117
		char ch7 = 'a';
		System.out.println((int) ch7);
		char ch8 = 's';
		System.out.println((int) ch8);
		
		char ch9 = 'e';
		System.out.println((int) ch9);
		
		char ch10 = 'f';
		System.out.println((int) ch10);
		
		char ch11 = 'g';
		System.out.println((int) ch11);
		
		char ch12 = 'h';
		System.out.println((int) ch12);
		
		char ch13 = 'i';
		System.out.println((int) ch13);
		
		char ch14 = 'j';
		System.out.println((int) ch14);
		
		char ch15 = 'k';
		System.out.println((int) ch15);
		
		char ch16 = '유';
		System.out.println((int)ch16); // 50976
		
		char ch17 = '제';
		System.out.println((int)ch17); // 51228
		
		char ch18 = '상';
		System.out.println((int)ch18); // 49345
		
		char ch19 = '劉';
		System.out.println((int)ch19); // 63943
		
		char ch20 = '齊';
		System.out.println((int)ch20); // 40778
		
		char ch21 = '相';
		System.out.println((int)ch21); // 30456
		
		int number1 = 63943;
		System.out.println((char) number1);
		
		int number2 = 40778;
		System.out.println((char) number2);
		
		int number3 = 30456;
		System.out.println((char) number3);
		
		int number4 = 50976;
		System.out.println((char) number4);
		
		int number5 = 51228;
		System.out.println((char) number5);
		
		int number6 = 49345;
		System.out.println((char) number6);
		
		
		
	}

}
